<?php
    include "database.php";
    $sql = "SELECT * FROM item";
    $result = $db->query($sql);

    if ($result->num_rows > 0) {
        // Output table header
        echo "<table border='1'>
                <tr>
                    <th>ID</th>
                    <th>Status</th>
                    <th>Item Name</th>
                    <th>Panjang</th>
                    <th>Lebar</th>
                    <th>Tinggi</th>
                    <th>Weight (kg)</th>
                    <th>Category</th>
                    <th>Shipping Cost</th>
                    <th>Order Received</th>
                    <th>Order Completed</th>
                    <th>Location From</th>
                    <th>Sender Name</th>
                    <th>Sender Phone Num</th>
                    <th>Location To</th>
                    <th>Receiver Name</th>
                    <th>Receiver Phone Num</th>
                </tr>";
    
        // Output data of each row
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                    <td>".$row["id"]."</td>
                    <td>".$row["status"]."</td>
                    <td>".$row["item_name"]."</td>
                    <td>".$row["panjang"]."</td>
                    <td>".$row["lebar"]."</td>
                    <td>".$row["tinggi"]."</td>
                    <td>".$row["weight_kg"]."</td>
                    <td>".$row["category"]."</td>
                    <td>".$row["shipping_cost"]."</td>
                    <td>".$row["order_received"]."</td>
                    <td>".$row["order_completed"]."</td>
                    <td>".$row["id_location_from"]."</td>
                    <td>".$row["sender_name"]."</td>
                    <td>".$row["sender_phone_num"]."</td>
                    <td>".$row["id_location_to"]."</td>
                    <td>".$row["receiver_name"]."</td>
                    <td>".$row["receiver_phone_num"]."</td>
                  </tr>";
        }
        echo "</table>";
    } else {
        echo "0 results";
    }

?>

<!DOCTYPE html>
<html>
<head>
    <title>Add Button Example</title>
</head>
<body>
    <button onclick="redirectToNewPage()">Add</button>

    <script>
        function redirectToNewPage() {
            // Redirect to the new page when the "Add" button is clicked
            window.location.href = "add_item.php";
        }
    </script>
</body>
</html>
